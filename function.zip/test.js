// dependencies
const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
const crypto = require('crypto');

// get reference to S3 client
const s3 = new AWS.S3();
const queueUrl = 'https://sqs.us-east-1.amazonaws.com/706574619075/new_webpage_queue';
const Bucket = "csce678-project";
const sqs = new AWS.SQS({apiVersion: '2012-11-05'});

// // get all keys 
// function checkNewPages() {
//     // s3.listObjectsV2({ Bucket }, function(err, data) {
//     //     console.log("Check for new webpages...")
//     //     if (err) console.log(err, err.stack); // an error occurred
//     //     else {
            
//     //         let hashedKeysWithoutSuffix = new Set();
//     //         let newKeys = [];
//     //         data.Contents.forEach(obj => {
//     //             if (obj.Key.endsWith("-hash")) hashedKeysWithoutSuffix.add(obj.Key.slice(0, -5));
//     //             else newKeys.push(obj.Key);
//     //         });
//     //         // get the new webpages by keys
//     //         newKeys = newKeys.filter(key => !hashedKeysWithoutSuffix.has(key));
//     //         // process the new webpages
//     //         console.log("Found", newKeys.length, "new webpages");
//     //         newKeys.forEach(Key => {
//     //             s3.getObject( { Bucket, Key }, (err, data) => {
//     //                 if (err) console.log("err", err.stack); // an error occurred
//     //                 else {
//     //                     //console.log("data", data.Body.toString());           // successful response
//     //                     // hash the content with sha256
//     //                     const hashedContent = crypto.createHash('sha256').update(data.Body.toString()).digest('base64');
//     //                     s3.putObject({ Bucket, Key:Key + "-hash", Body:hashedContent }, (err, data) => {
//     //                         if (err) console.log(err, err.stack); // an error occurred
//     //                         else     console.log("Hashed and Stored the page", Key, "Successfully!");           // successful response
//     //                     });
//     //                 }
//     //             });
//     //         });
//     //     }
//     // });
// }

// setInterval(() => checkNewPages(), 5000);


var params = {
    MessageBody: 'STRING_VALUE', /* required */
    QueueUrl: queueUrl, /* required */
};

sqs.sendMessage(params, function(err, data) {
    if (err) console.log(err, err.stack); // an error occurred
    else     console.log(data);           // successful response
});